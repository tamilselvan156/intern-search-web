// Simple interactive demo
document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', function () {
    const label = this.textContent;
    if (label.includes('Apply') || label.includes('Sign Up') || label.includes('Get Started')) {
      alert('✅ This would navigate to the application page in the full version!');
    }
  });
});
